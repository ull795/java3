package java5;

public class Card {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Card c = new Card();
		Card c1 = new Card();
		System.out.println(c);
		System.out.println(c.toString());
		System.out.println("======================");
		
		System.out.println(c.hashCode());
		System.out.println(c.equals(c1));
	}

}
