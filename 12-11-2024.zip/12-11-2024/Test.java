package java5;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 1. empty representation of the string object
		String s = new String();
		System.out.println(s);
		
		//2. passing set of characters
		String s1 = new String("Ullas");
		System.out.println(s1);
		//converting char[] into string object
		char[] c = {'j','a','v','a'};
		String s2 = new String(c);
		System.out.println(s2);
	}

}
