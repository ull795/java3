package java5;

public class ExampleForComparision {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "JAVA";
		String s1 = "JAVA";
		if(s == s1)
		{
			System.out.println("equal");
		}
		else
		{
			System.out.println("not equal");
		}
	}

}
