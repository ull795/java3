package java5;

public class ExampleForComparision1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = new String("java");
		String s2 = new String("java");
		if(s1.equals(s2))
		{
			System.out.println("equal");
		}
		else
		{
			System.out.println("not equal");
		}
		
		System.out.println("_______________________________");
		String s3 = new String("java");
		String s4 = new String("Java");
		if(s3.equals(s4))
		{
			System.out.println("equal");
		}
		else
		{
			System.out.println("not equal");
		}
		System.out.println("_______________________________");
		String s5 = new String("java");
		String s6 = new String("Java");
		if(s5.equalsIgnoreCase(s6))
		{
			System.out.println("equal");
		}
		else
		{
			System.out.println("not equal");
		}
		
	}

}
